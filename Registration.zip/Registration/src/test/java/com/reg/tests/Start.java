package com.reg.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.Base;


public class Start extends Base{
	
	
	@Test(enabled = true, priority = 1)
	public void registration() throws InterruptedException {
	

		long currentTime = System.currentTimeMillis() ;
		System.out.println("User on Account Creation Page");
		driver.findElement(By.id("email_create")).sendKeys("xyz"+currentTime+"@abc.com");
		System.out.println("Email ID entered");
		driver.findElement(By.id("SubmitCreate")).click();
		System.out.println("User Email submission done");
		Thread.sleep(5000);
		System.out.println("ddsd"+driver.getTitle());
			System.out.println("User on Second Page");	
			driver.findElement(By.id("id_gender1")).click();
			System.out.println("Gender Selected");
			
			driver.findElement(By.id("customer_firstname")).sendKeys("Alim");
			System.out.println("First NAme");
			
			driver.findElement(By.id("customer_lastname")).sendKeys("Khan");
			System.out.println("Last Name");
			
			driver.findElement(By.id("passwd")).sendKeys("India@123");
			System.out.println("Password Entered");
			
			
			driver.findElement(By.id("address1")).sendKeys("231, ABC Jaipur");
			System.out.println("Address Entered");
			
			
			
			driver.findElement(By.id("city")).sendKeys("Jaipur");
			System.out.println("City Entered");
			
			Thread.sleep(5000);
			driver.findElement(By.id("id_state")).click();
			Thread.sleep(5000);
					
			
			driver.findElement(By.id("postcode")).sendKeys("40014");
			System.out.println("Zipcode Entered");
			
			driver.findElement(By.id("other")).sendKeys("Additional Info added for test");
			System.out.println("Additional Info Entered");
			
			
			driver.findElement(By.id("phone_mobile")).sendKeys("985747");
			System.out.println("Mobile Number Entered");
			
			
			driver.findElement(By.id("submitAccount")).click();
			
			
	}

	 
}

