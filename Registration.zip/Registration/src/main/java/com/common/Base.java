package com.common;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class Base {

	
	public WebDriver driver ;
	
	@BeforeMethod
	public void LCBTest()  {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Alim\\GeM\\Registration\\conf\\chromedriver.exe");
		
	    driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
	}

	@AfterMethod
	public void quitfunction() {
		driver.quit();
	}

}
